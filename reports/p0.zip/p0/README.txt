Trabalho - P0 - Computação Gráfica

Autores:
Gabriel Medina Braga (medina_cdz@hotmail.com)
Mário de Araújo Carvalho (mariodearaujocarvalho@gmail.com)

Descricao: 
As atividades A1 e A2 foram realizadas. 