//[]---------------------------------------------------------------[]
//|                                                                 |
//| Copyright (C) 2018 Orthrus Group.                               |
//|                                                                 |
//| This software is provided 'as-is', without any express or       |
//| implied warranty. In no event will the authors be held liable   |
//| for any damages arising from the use of this software.          |
//|                                                                 |
//| Permission is granted to anyone to use this software for any    |
//| purpose, including commercial applications, and to alter it and |
//| redistribute it freely, subject to the following restrictions:  |
//|                                                                 |
//| 1. The origin of this software must not be misrepresented; you  |
//| must not claim that you wrote the original software. If you use |
//| this software in a product, an acknowledgment in the product    |
//| documentation would be appreciated but is not required.         |
//|                                                                 |
//| 2. Altered source versions must be plainly marked as such, and  |
//| must not be misrepresented as being the original software.      |
//|                                                                 |
//| 3. This notice may not be removed or altered from any source    |
//| distribution.                                                   |
//|                                                                 |
//[]---------------------------------------------------------------[]
//
// OVERVIEW: Material.h
// ========
// Class definition for material.
//
// Author(s): Paulo Pagliosa (and your name)
// Last revision: 05/10/2018

#ifndef __Material_h
#define __Material_h

#include "graphics/Color.h"

namespace cg
{ // begin namespace cg


/////////////////////////////////////////////////////////////////////
//
// Material: material class
// ========
class Material
{
public:
  Color ambient; // ambient color
  Color diffuse; // diffuse color
  Color spot; // specular spot color
  float shine; // specular spot exponent
  Color specular; // specular color

  Material(const Color& color = Color::white):
    ambient{0.2f * color},
    diffuse{0.8f * color},
		//spot{ Color::red },
    shine{100}
  {
		spot = Color::white;
		specular = Color::red;
  }

}; // Material

} // end namespace cg

#endif // __Material_h
