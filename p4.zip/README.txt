Trabalho - P4 - Computa��o Gr�fica 

Autores:
Gabriel Medina Braga (medina_cdz@hotmail.com)
M�rio de Ara�jo Carvalho (mariodearaujocarvalho@gmail.com)

Descri��o: 
Todas as atividades foram realizadas. 

A1: Feito.
A2: Feito mas como foi substitu�do por A3, portanto alguns erros de implementa��o n�o foram corrigidos, uma vez que a BVH foi implementada.

A3: Feito.
A4: Feito. 

A5: Foram criadas duas cenas: Slender Scene e Mirrors Scene. 
	A "Slender Scene" visa demonstrar que as luzes spot e point funcionam, assim como as propriedades de reflex�o especular de alguns objetos de cena.
	A "Mirrors Scene" demonstra todo o poder do tra�ador de raios para reflex�es especulares, utilizando uma luz direcional e uma luz spot.
Obs.: Cada cena j� vem com pelo menos uma c�mera corrente.
Obs.: H� um bug na execu��o do arquivo execut�vel, eventualmente, o mesmo n�o executa no modo Renderer corretamente. Mas se o programa for executado diretamente pelo Visual Studio, este problema n�o acontece.